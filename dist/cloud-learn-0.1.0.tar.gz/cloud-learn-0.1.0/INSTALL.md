# CloudLearn installation

## Source checkout

From the repository root:

```bash
bash ./scripts/cloud-learn up
```

This starts the simulator stack with Docker Compose.

## Homebrew

The repository now includes a Homebrew formula scaffold under:

`packaging/homebrew/Formula/cloud-learn.rb`

The intended release flow is:

1. Build a release tarball.
2. Publish the tarball.
3. Update the formula `url` and `sha256`.
4. Add the formula to a tap.
5. Install with:

```bash
brew install cloud-learn
```

The installed `cloud-learn` command wraps the same Compose-based launcher.

## Release tooling

To build a versioned tarball and print the sha256:

```bash
bash ./scripts/build-release.sh
```

To update the Homebrew formula with that sha256:

```bash
bash ./scripts/update-homebrew-formula.sh <sha256>
```

The release version is read from `VERSION`.

## Runtime notes

- Docker and Docker Compose are required.
- EC2 instances use LXD-backed runtime semantics where possible.
- On first EC2 launch, the runtime attempts to bootstrap LXD automatically.
- LXD images are downloaded on demand and cached on first use.
