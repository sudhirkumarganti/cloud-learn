class CloudLearn < Formula
  desc "Local multi-cloud simulator with a CloudSim backbone"
  homepage "https://example.com/cloud-learn"
  url "https://example.com/releases/cloud-learn-0.1.0.tar.gz"
  sha256 "0000000000000000000000000000000000000000000000000000000000000000"
  license "MIT"

  def install
    libexec.install "Dockerfile"
    libexec.install "CLOUDLEARN_DESIGN.md"
    libexec.install "CLOUDLEARN_FULL_ARCHITECTURE.md"
    libexec.install "CLOUDLEARN_LLD.md"
    libexec.install "cloudlearn_platform.py"
    libexec.install "cloudsim-backbone"
    libexec.install "docker-compose.yml"
    libexec.install "generate_cloudlearn_full_architecture_pdf.py"
    libexec.install "generate_cloudlearn_lld_pdf.py"
    libexec.install "requirements.txt"
    libexec.install "scripts"
    libexec.install "server.py"
    libexec.install "static"

    (bin/"cloud-learn").write <<~EOS
      #!/usr/bin/env bash
      export CLOUD_LEARN_HOME="#{libexec}"
      exec bash "#{libexec}/scripts/cloud-learn" "$@"
    EOS
    chmod 0555, bin/"cloud-learn"
  end

  def caveats
    <<~EOS
      CloudLearn runs through Docker Compose.
      You still need Docker and Docker Compose available on the host.

      EC2 runtime instances are LXD-backed where possible. The first EC2 launch
      will attempt to bootstrap LXD automatically inside the runtime workflow.

      If the host cannot support unattended bootstrap, install LXD manually
      and rerun the launch.
    EOS
  end

  test do
    assert_match "cloud-learn", shell_output("#{bin}/cloud-learn help")
  end
end
