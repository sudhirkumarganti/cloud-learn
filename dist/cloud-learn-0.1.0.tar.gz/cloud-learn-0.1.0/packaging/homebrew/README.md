# Homebrew packaging

This directory contains the Homebrew formula scaffold for CloudLearn.

## Intended flow

1. Publish a release tarball for CloudLearn.
2. Run `bash ./scripts/build-release.sh`.
3. Run `bash ./scripts/update-homebrew-formula.sh <sha256>`.
4. Update `Formula/cloud-learn.rb` with the release `url` and `sha256`.
5. Add the formula to a Homebrew tap.
6. Install with:

```bash
brew install cloud-learn
```

## What the formula installs

- `cloud-learn` launcher in `bin`
- the Compose bundle
- the CloudSim sidecar source
- the simulator backend
- docs and scripts

## Runtime expectations

The installed launcher still expects:

- Docker
- Docker Compose

At first EC2 launch, the runtime will try to bootstrap LXD automatically if it is not already available.

## Local development

For source checkout usage, run:

```bash
bash ./scripts/cloud-learn up
```

That uses the same launcher logic as the package install path.
